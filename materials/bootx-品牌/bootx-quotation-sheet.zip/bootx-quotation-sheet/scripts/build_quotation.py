# -*- coding: utf-8 -*-
"""生成一页纸客户报价单（黑金主题，复用 bootx docx_blocks）。

用法：
    python build_quotation.py 输出路径.docx [--logo 客户logo.png]

脚本内置威吉瑞示例数据。实际使用时，替换本文件顶部的
CLIENT / QUOTE_NO / MODULES / 首期 / 个人微信专项 / 边界 / 付款 即可。
所有报价均为参考区间，最终以功能对齐后的详细工作量为准。

样式说明：黑金主题（见 docx_blocks.PALETTE）、不插版本号、
不写破折号、不加字面星号、不加英文副标题，按 humanizer 去 AI 腔。
"""
import sys, os, argparse
import docx_blocks as B
from docx.shared import Cm, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

# ===================== 示例数据：威吉瑞 =====================
CLIENT   = "威吉瑞"
QUOTE_NO = "BOOTX-2026-WJR-001"
DATE     = "2026-08-17"
VALID    = "30 日"
LOGO     = None  # 命令行 --logo 覆盖；留空则不插 Logo

# 模块化报价总表（全量视角，单位：万元）
MODULES = [
    ("M1a 客服机器人", "企微/通道 FAQ 助手，30–50 条", "2 – 3", "1.2 – 1.8"),
    ("M1b 企业知识库", "RAG 知识库搭建与入库", "2 – 3", "1.0 – 1.5"),
    ("M1c 语气蒸馏",   "历史聊天分析、多语气模板", "2 – 3", "0.8 – 1.2"),
    ("M2 客户管理",    "画像/打标/分层，≤300 条/5 账号", "2 – 3", "1.0 – 1.5"),
    ("M3 任务与进度",  "大客户项目进度管理", "2 – 3", "1.0 – 1.5"),
    ("M4 咨询问答",    "复用 M1 底座，扩展咨询场景", "2 – 3", "1.5 – 2.5"),
    ("M5 流程标准化",  "沟通/媒体发布流程 AI 化", "3 – 4", "1.5 – 2.5"),
    ("M6 新媒体运营",  "公众号/视频号 AI 生成发布", "3 – 4", "1.5 – 2.5"),
    ("M7 记账重构",    "系统底座重构（独立立项）", "8+", "10+"),
    ("M8 数字员工",    "财务场景数字员工", "4 – 6", "3 – 5"),
]
MODULES_TOTAL = "全量建设价（M1+M2 示例）"

# 首期推荐（方案 A，验证优先）
FIRST_PHASE = [
    ("首期 · 业务流程梳理", "现状流程盘点与标准化建议", "0.3"),
    ("首期 · 客户管理",     "≤300 条 / 5 账号打标分层", "0.4 – 0.6"),
    ("首期 · 待跟进",       "微信沟通待办归集与提醒", "0.3"),
    ("首期 · AI 客服助手",  "FAQ 30–50 条 + 试运行", "1.2 – 1.5"),
    ("首期 · 试运行报告",   "价值验证与优化建议", "0.3"),
]
FIRST_TOTAL = "2.48 – 2.98"

# 个人微信自动化专项（危险项，必须单列）
WECHAT_SPECIAL = [
    ("技术可行性验证", "导出两个号聊天记录、验证自动读取/发送可行性与风控边界", "0.98 – 1.58"),
    ("单账号试点",     "验证通过后，单微信号单设备试点运行", "5.0 起"),
]
WECHAT_TOTAL = "含该能力首期 5.98 – 8.56 起"

# 专项边界（warn）
BOUNDARY = [
    "以验证结果为准：不把需求描述直接视为已实现。",
    "平台风险不承诺：平台规则、账号风控、登录状态变化造成的不可用，不属于平台稳定性保证。",
    "合规告知义务：贵司须保证有权处理相关信息，并履行对内、对客告知。",
    "发送范围受限：税务案件、重大风险、报价承诺、正式申报类内容不得默认自动发送。",
    "交付边界：交付约定范围内的系统能力，不是无限期代运营。",
]

# 商务模式
MODELS = [
    "① 项目制交付：一次性开发费。",
    "② 验证 + 试点制：降低首决策门槛，先验证再扩展。",
    "③ 持续服务：年维护费 10–15% + 知识库运营 + 技术支持。",
    "④ 扩展计费：按账号 / 设备 / 场景数计费。",
    "⑤ 知识付费配套：内训 + 内部 FDE 培养 + 维护订阅，知识留在企业。",
]

# 付款与抵扣
PAYMENT = [
    ("技术验证", "签约 60% 启动 + 提交报告 40%；未通过不自动承诺退款"),
    ("试点开发", "50% 启动 + 30% 可用版 + 20% 验收"),
    ("抵扣机制", "验证结束 30 日内签正式扩展合同，可约定部分或全部验证费抵扣后续开发费"),
]

# 知识付费配套（可选增值）：员工培训 + 内部 FDE 培养 + 交付后维护
# 定价原则（初创小团队，2026-08 调研校准）：
# 1) 取市场区间偏低端，不按大机构行情（内训师养成 20-50 万/期 是讲师型，带教型按规模折算）；
# 2) 顾问费与第三方费用分离：模型/API/平台订阅由客户自持账号支付，我方不垫长期费用；
# 3) 维护年费按行业下限（常规维护约总价 10%，定制 12-25%，取 10-15%）。
KNOWLEDGE_NOTE = [
    ("知识付费配套：", True, B.ACCENT),
    ("不止交付系统，还帮贵司培养能自维护的内部 FDE，让知识与能力留在企业。", False, B.INK),
    ("第三方费用分离：模型 / API / 平台订阅由贵司自持账号支付，我方只收顾问与实施费，不垫长期费用。", True, B.ACCENT2),
]
KNOWLEDGE_ITEMS = [
    ("内部 FDE 培养包（核心）", "选 1–2 名员工，4–6 周带教 + 上岗认证 + 90 天远程支持，结业可独立维护系统与知识库", "2.8 – 4.8 万/人"),
    ("交付后维护年费", "按已交付建设费 10 – 15%/年：知识库更新、话术与模型优化、月度答疑、季度复盘；或人天包 10 – 20 人天/年，超出 1500 – 3000 元/人天", ""),
]
KNOWLEDGE_BENEFIT = "培养 FDE 后维护费按行业下限（10–15%）：内部人处理日常维护，我们只接管复杂问题。"
# =========================================================

def shaded_block(doc, lines, style='accent'):
    """底色块提示（段落实现，不用表格格子）。lines 支持 list[str] 或 list[list[(txt,bold,color)]]。"""
    bg = {'accent': B.ACCENT_SOFT, 'gold': B.ACCENT2_SOFT, 'warn': B.WARN_BG}[style]
    edge = {'accent': B.ACCENT, 'gold': B.ACCENT2, 'warn': B.TOP}[style]
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.space_before = Pt(4); pf.space_after = Pt(6)
    pf.left_indent = Cm(0.2); pf.right_indent = Cm(0.2); pf.line_spacing = 1.4
    pPr = p._p.get_or_add_pPr()
    shd = OxmlElement('w:shd'); shd.set(qn('w:val'), 'clear'); shd.set(qn('w:color'), 'auto'); shd.set(qn('w:fill'), bg)
    pPr.append(shd)
    pbdr = OxmlElement('w:pBdr'); left = OxmlElement('w:left')
    left.set(qn('w:val'), 'single'); left.set(qn('w:sz'), '18'); left.set(qn('w:space'), '6'); left.set(qn('w:color'), edge)
    pbdr.append(left); pPr.append(pbdr)
    if isinstance(lines, list) and lines and isinstance(lines[0], list):
        for i, seg in enumerate(lines):
            if i > 0: p.add_run().add_break()
            for (txt, b, col) in seg:
                r = p.add_run(txt); B.set_font(r, size=10.5, bold=b, color=col or B.INK)
    else:
        for i, line in enumerate(lines):
            if i > 0: p.add_run().add_break()
            r = p.add_run(line); B.set_font(r, size=10.5, color=B.INK)
    return p

def stacked(doc, rows, val_suffix='万'):
    """堆叠条目（段落实现，不用表格格子）。row 支持 (label,desc,val) 或 (label,desc)。"""
    for row in rows:
        p = doc.add_paragraph(); pf = p.paragraph_format
        pf.space_after = Pt(3); pf.left_indent = Cm(0.3); pf.line_spacing = 1.3
        if len(row) == 3:
            label, desc, val = row
            r = p.add_run(label + '：'); B.set_font(r, size=10, bold=True, color=B.ACCENT)
            r = p.add_run(desc + '　'); B.set_font(r, size=10, color=B.INK)
            r = p.add_run(val + ' ' + val_suffix); B.set_font(r, size=10, bold=True, color=B.ACCENT2)
        elif len(row) == 2:
            label, desc = row
            r = p.add_run(label + '：'); B.set_font(r, size=10, bold=True, color=B.ACCENT)
            r = p.add_run(desc); B.set_font(r, size=10, color=B.INK)
        else:
            r = p.add_run(row[0]); B.set_font(r, size=10, color=B.INK)

# =========================================================

def build(out_path, logo_path=None):
    doc = B.new_doc()

    # ---- 报头 ----
    if logo_path and os.path.exists(logo_path):
        lp = doc.add_paragraph(); lp.alignment = WD_ALIGN_PARAGRAPH.CENTER; lp.paragraph_format.space_after = Pt(6)
        lp.add_run('').add_picture(logo_path, width=Cm(3.5))
    t = doc.add_paragraph(); t.alignment = WD_ALIGN_PARAGRAPH.CENTER; t.paragraph_format.space_after = Pt(2)
    r = t.add_run(f'{CLIENT} · 财税 AI 转型 报价单'); B.set_font(r, size=22, bold=True, color=B.ACCENT)
    meta = doc.add_paragraph(); meta.alignment = WD_ALIGN_PARAGRAPH.CENTER; meta.paragraph_format.space_after = Pt(2)
    r = meta.add_run(f'报价单号 {QUOTE_NO}　|　日期 {DATE}　|　有效期 {VALID}'); B.set_font(r, size=9.5, color=B.MUTED)
    B.spacer(doc, 4)

    # ---- 报价摘要 ----
    shaded_block(doc, [
        [("首期推荐（方案 A，基础客服提效验证）：", True, B.ACCENT), (f"{FIRST_TOTAL} 万元", True, B.ACCENT2)],
        [("可选含个人微信自动化：", True, B.ACCENT), (f"{WECHAT_TOTAL} 万元起（须先技术验证）", True, B.TOP)],
    ], style='accent')

    # ---- 模块化报价总表 ----
    B.h3(doc, "一、模块化报价总表（全量视角）")
    B.data_table(doc,
        ["模块", "范围要点", "工期(周)", "报价(万)"],
        [list(m) for m in MODULES],
        widths_cm=[3.4, 8.0, 2.2, 2.4],
        total_text=MODULES_TOTAL, total_val="8.5 – 13.5+", merge_total=3)

    # ---- 首期推荐 ----
    B.h3(doc, "二、首期推荐（方案 A，验证优先）")
    stacked(doc, [list(x) for x in FIRST_PHASE], val_suffix='万')
    p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(2); p.paragraph_format.left_indent = Cm(0.3)
    r = p.add_run(f'首期合计：{FIRST_TOTAL} 万元'); B.set_font(r, size=10.5, bold=True, color=B.ACCENT2)
    B.spacer(doc, 2)

    # ---- 个人微信专项（危险项） ----
    B.h3(doc, "三、个人微信自动化专项（风险项，须单列）")
    shaded_block(doc, [
        [("注意：", True, B.TOP), ("个人微信的自动读取聊天与自动发送受平台规则约束，与企业微信官方接口不同，", False, B.INK),
         ("不能按普通项目直接承诺，", True, B.TOP), ("须先技术验证、再试点，不得免费捆绑进首期。", False, B.INK)],
    ], style='warn')
    B.data_table(doc,
        ["项目", "说明", "报价(万)"],
        [list(x) for x in WECHAT_SPECIAL],
        widths_cm=[3.4, 9.0, 2.6],
        total_text=WECHAT_TOTAL, total_val="起", merge_total=2)

    # ---- 专项边界 ----
    B.h3(doc, "四、专项边界")
    shaded_block(doc, BOUNDARY, style='warn')

    # ---- 商务模式与付款 ----
    B.h3(doc, "五、商务模式")
    for m in MODELS:
        B.para(doc, m, size=10, after=2)
    B.h3(doc, "六、付款与抵扣")
    stacked(doc, [[a, b] for a, b in PAYMENT])

    # ---- 知识付费配套（可选增值） ----
    B.h3(doc, "七、知识付费配套 · 内部能力共建（可选）")
    shaded_block(doc, [KNOWLEDGE_NOTE], style='accent')
    stacked(doc, KNOWLEDGE_ITEMS, val_suffix='')
    p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(2); p.paragraph_format.left_indent = Cm(0.3)
    r = p.add_run(KNOWLEDGE_BENEFIT); B.set_font(r, size=9.5, color=B.MUTED)
    B.spacer(doc, 2)

    B.spacer(doc, 6)
    B.para(doc, "以上为参考区间，最终以功能对齐后的详细工作量为准。", size=9, color=B.MUTED, align=WD_ALIGN_PARAGRAPH.CENTER)

    B.save_doc(doc, out_path)
    return out_path

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('out', nargs='?', default='/tmp/bootx_quotation_demo.docx')
    ap.add_argument('--logo', default=None)
    args = ap.parse_args()
    logo = args.logo or LOGO
    p = build(args.out, logo)
    print("生成报价单:", p)
