---
name: bootx-quotation-sheet
description: "This skill helps bootx produce a one-page client-facing quotation sheet (报价单) after a requirements-confirmation document is done. Use it when a service-enterprise prospect has agreed on scope and bootx needs to issue a formal, modular price quote with clear boundaries. It encodes the validation-first quotation logic, the risky personal-WeChat automation item quoted separately, the business models and payment terms, the black-gold client-facing style, and the DOCX build pipeline that reuses bootx docx_blocks."
---

# bootx 一页纸报价单生成

在 `bootx-requirements-plan`（需求确认与方案规划）完成、客户已认可需求范围之后，用本技能生成
**面向客户的一页纸报价单**。报价单是需求确认书的"商务落地页"：把模块价表、首期推荐、风险项单列、
边界与付款规则浓缩成一页可签发的文件。

## 何时使用
- 客户已确认需求（或至少确认首期范围），需要一份正式报价单去走内部审批或签约。
- 场景通常是财税 / 企业服务 / AI 转型类 ToB 客户，首期预算有限、要先验证再扩展。
- 本技能**依赖** `bootx-requirements-plan` 的需求结论（模块 M1–M8、首期口径、个人微信约束）。
  若尚未做需求确认，先跑 requirements-plan。

## 工作流

### 1. 取需求结论
从需求确认文档提取：模块清单（M1a/M1b/M1c/M2/M3/M4/M5/M6/M7/M8）、首期推荐口径、
个人微信资产规模与约束、客户自述数据来源标注。不要凭空编报价。

### 2. 套用报价逻辑
按 `references/quotation_sheet.md` 的口径：
- 模块化总表（全量视角）：每个模块单独报价（万元），便于客户按优先级组合。
- 首期推荐（验证优先）：小成本跑通价值，如方案 A 基础客服提效验证 2.48–2.98 万。
- **危险项必须单列**：个人微信"自动读取聊天 + 自动发送"受平台规则约束，不能按普通项目承诺。
  先技术验证（0.98–1.58 万）单列，通过后再单账号试点（5.0 万起）；首期不得免费捆绑。
- 含该能力时首期 5.98–8.56 万起。

### 3. 标注数据来源
客户自述数据（一人服务 100→500/1000 家、工商前期沟通占 80%、7000 个微信客户）标注"来自贵司描述"，
不伪造、不夸大。

### 4. 套用样式规则
严格遵循 `references/style_rules.md`：黑金主题、客户 Logo 插入、不要版本号 / 破折号 / 字面星号 /
英文章节副标题、humanizer 去 AI 腔。

### 5. 生成一页纸 DOCX
用 `scripts/build_quotation.py`（复用 `scripts/docx_blocks.py` 的黑金排版积木）。
脚本内置威吉瑞示例数据，替换顶部的 CLIENT / MODULES / 首期 / 个人微信专项 / 边界 / 付款 即可。
命令：
```
python scripts/build_quotation.py 输出路径.docx [--logo 客户logo.png]
```

### 6. 可选导出 PDF
需要打印版时：`Google Chrome --headless --print-to-pdf` 渲染同内容 HTML，或直接把 docx 另存 PDF。
（架构图非必需，一页纸以表格为主。）

### 7. 复核清单
- 无破折号、无字面 `**`、无英文章节副标题。
- 模块化总表（全量）与首期推荐（验证）口径不矛盾，且已在文中说明"两者口径不同"。
- 个人微信专项显眼单列，边界条款（平台风险不承诺、合规告知、发送范围受限）完整。
- 付款比例与抵扣机制清晰。

## 与其他 bootx 技能的关系
- `bootx-requirements-plan`：上游，产出需求确认书。本技能是它的商务落地。
- `bootx-合同边界`（待建）：把本技能 7.4 的边界条款扩成正式合同附件。

## 注意事项
- 报价均为参考区间，最终以功能对齐后的详细工作量为准；文档中必须写明这句话。
- RAG 命中率、一人服务家数等"同类实践数据"是示意，不对客户承诺。
- 个人微信自动化属于受平台规则约束的渠道能力，任何"稳定性保证"都不可写。
